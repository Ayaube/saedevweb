package fr.montreuil.iut.Lucas_Adrien_Imman.modele.Deplacement;

import fr.montreuil.iut.Lucas_Adrien_Imman.modele.Deplaçable;

public interface ModeDeplacement {

    public abstract void seDeplacer(Deplaçable d);

}

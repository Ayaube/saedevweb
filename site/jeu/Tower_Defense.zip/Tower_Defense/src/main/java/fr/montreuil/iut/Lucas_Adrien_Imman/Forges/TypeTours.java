package fr.montreuil.iut.Lucas_Adrien_Imman.Forges;

public class TypeTours {
}

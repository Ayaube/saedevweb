package fr.montreuil.iut.Lucas_Adrien_Imman.Forges;

public enum TypeEnnemis {

    DotSh,
    DotExe,
    Archive,
    Kamikaze,
    Scam,
    Virus,



}

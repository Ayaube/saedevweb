package fr.montreuil.iut.Lucas_Adrien_Imman.modele.Deplacement;

import fr.montreuil.iut.Lucas_Adrien_Imman.modele.Deplaçable;

public class DeplacementBFS implements ModeDeplacement{


    @Override
    public void seDeplacer(Deplaçable d) {

    }
}

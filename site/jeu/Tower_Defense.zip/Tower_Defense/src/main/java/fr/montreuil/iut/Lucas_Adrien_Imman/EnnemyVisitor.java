package fr.montreuil.iut.Lucas_Adrien_Imman;

import fr.montreuil.iut.Lucas_Adrien_Imman.modele.Ennemis.DotSH;

public interface  EnnemyVisitor {

    boolean visit(DotSH dotSH);


}
